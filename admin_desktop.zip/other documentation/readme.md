# README for User Management System

## Overview
This project includes various types of documentation to assist in understanding file structures and types.

## Contents
- Admin Schedule
- API Documentation
- Budget Information
- Meeting Minutes
- Other Project Documentation

## Getting Started
To get started, navigate through the directories to find relevant documentation and resources for each aspect of the project.
