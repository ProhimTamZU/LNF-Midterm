-- SQL Script to Create Budget Table
CREATE TABLE budget (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT
);

INSERT INTO budget (category, amount, description) VALUES
('Marketing', 5000, 'Advertising and promotional activities'),
('Development', 15000, 'Software development and testing costs'),
('Operations', 7000, 'General operational expenses'),
('Training', 3000, 'Employee training and development');
